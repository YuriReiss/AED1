#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

int main () {


	lista_libera(p);
	lista_libera(q);
	return 0;
}
